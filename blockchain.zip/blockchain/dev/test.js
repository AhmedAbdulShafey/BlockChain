const Blockchain = require('./blockchain.js')

var bitcoin = new Blockchain()


var bc1 ={
    "chain": [
    {
    "index": 1,
    "timestamp": 1612248575618,
    "transactions": [],
    "nonce": 100,
    "hash": "0",
    "previousBlockHash": "0"
    },
    {
    "index": 2,
    "timestamp": 1612248768355,
    "transactions": [],
    "nonce": 18140,
    "hash": "0000b9135b054d1131392c9eb9d03b0111d4b516824a03c35639e12858912100",
    "previousBlockHash": "0"
    },
    {
    "index": 3,
    "timestamp": 1612248822635,
    "transactions": [
    {
    "amount": 12.5,
    "sender": "00",
    "reciever": "c269e66d131844e2a7658a352edf46ed",
    "transactionId": "96a0afa070f44388bf7c9a009de0a08c"
    },
    {
    "amount": 10,
    "sender": "Hadi",
    "reciever": "Shafey",
    "transactionId": "ae1467e03ceb4ffb92ed15dabacaeba1"
    },
    {
    "amount": 20,
    "sender": "Hadi",
    "reciever": "Shafey",
    "transactionId": "7abf6a5daeb34023bfac8b4927c04348"
    },
    {
    "amount": 30,
    "sender": "Hadi",
    "reciever": "Shafey",
    "transactionId": "e9f56ef3ff004a67b567ea014bfd02e4"
    }
    ],
    "nonce": 23607,
    "hash": "0000c11059f6bf6b805abf5f3291950820604f63ba392b19cf0648509dee09a4",
    "previousBlockHash": "0000b9135b054d1131392c9eb9d03b0111d4b516824a03c35639e12858912100"
    },
    {
    "index": 4,
    "timestamp": 1612248858125,
    "transactions": [
    {
    "amount": 12.5,
    "sender": "00",
    "reciever": "c269e66d131844e2a7658a352edf46ed",
    "transactionId": "689e4e5d794d4b0a8b8456dfd9a3ba4a"
    },
    {
    "amount": 40,
    "sender": "Hadi",
    "reciever": "Shafey",
    "transactionId": "446f4ed577be421da638472962ce5eba"
    },
    {
    "amount": 50,
    "sender": "Hadi",
    "reciever": "Shafey",
    "transactionId": "3ef17b9d277b408e9f11a3ce0d62332a"
    }
    ],
    "nonce": 22750,
    "hash": "0000ad6f1aff919d23d1dfc48e82b2f063b283178b50d0d3f344442f43888ef7",
    "previousBlockHash": "0000c11059f6bf6b805abf5f3291950820604f63ba392b19cf0648509dee09a4"
    },
    {
    "index": 5,
    "timestamp": 1612248874671,
    "transactions": [
    {
    "amount": 12.5,
    "sender": "00",
    "reciever": "c269e66d131844e2a7658a352edf46ed",
    "transactionId": "a9e79989607c441db1a6e29e6ff73018"
    }
    ],
    "nonce": 33169,
    "hash": "0000b2d6f748aed42618ad7b02d173c84612ef457dc9d6f44c6ccff53699124f",
    "previousBlockHash": "0000ad6f1aff919d23d1dfc48e82b2f063b283178b50d0d3f344442f43888ef7"
    },
    {
    "index": 6,
    "timestamp": 1612248880300,
    "transactions": [
    {
    "amount": 12.5,
    "sender": "00",
    "reciever": "c269e66d131844e2a7658a352edf46ed",
    "transactionId": "276a0d300f914320bf5e2b77807749eb"
    }
    ],
    "nonce": 24140,
    "hash": "0000ddf7305c9069ea3a4186aefd23cbc174c5983e5ae97b28d60aaefc41ac45",
    "previousBlockHash": "0000b2d6f748aed42618ad7b02d173c84612ef457dc9d6f44c6ccff53699124f"
    }
    ],
    "pendingtransactions": [
    {
    "amount": 12.5,
    "sender": "00",
    "reciever": "c269e66d131844e2a7658a352edf46ed",
    "transactionId": "4c6adf3e3fd448f4a374c7749410a9fa"
    }
    ],
    "currentNodeUrl": "http://localhost:3001",
    "networkNodes": []
    };



    console.log('VALID: ',bitcoin.chainIsValid(bc1.chain))