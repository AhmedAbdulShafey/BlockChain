var express = require('express')
var app = express()
var blockchain = require('./blockchain')
var uuid = require('uuid')
var port = process.argv[2];

var rp = require('request-promise')

var nodeAddress = uuid.v4().split('-').join('')


 var bitcoin = new blockchain()

var bodyParser = require('body-parser');
const { json } = require('body-parser');

app.use(bodyParser.json())

app.get('/blockchain',(req,res)=>{
    res.send(bitcoin)
});

app.post('/transaction',(req,res)=>{
     const newTransaction = req.body;
     const blockIndex = bitcoin.addTransactionToPendingTransaction(newTransaction)

    res.json({"note":`new transaction will be added to ${blockIndex}`});


//    var blockIndex = bitcoin.newTransaction(req.body.amount,req.body.sender,req.body.reciever)
//    res.json({note:`These transactions will be added in the ${blockIndex}`})
});

app.post('/transaction/broadcast',(req,res)=>{
    const newTransaction = bitcoin.createNewTransaction(req.body.amount,req.body.sender,req.body.reciever)
    bitcoin.pendingtransactions.push(newTransaction);

    var requestPromises = [];
    bitcoin.networkNodes.forEach(networkNodeUrl =>{
        const requestOptions = {
            uri : networkNodeUrl + '/transaction',
            method : 'POST',
            body : newTransaction,
            json : true
        }

        requestPromises.push(rp(requestOptions))
    });
    Promise.all(requestPromises)
    .then(data =>{
        res.json({"note" : "new transaction added and broadcast succesfully"})
    })
})


app.get('/mine',(req,res)=>{
   var lastBlock = bitcoin.getLastBlock()
   var previousBlockHash = lastBlock['hash']

   const currentBlockData ={
       transactions : bitcoin.pendingtransactions,
       index : lastBlock['index'] + 1 
   }

   var nonce = bitcoin.proofOfWork(previousBlockHash,currentBlockData)
   var hash = bitcoin.hashBlock(previousBlockHash,currentBlockData,nonce)
   
  // var reward = bitcoin.createNewTransaction(12.5,"00",nodeAddress)

   const newBlock = bitcoin.createNewBlock(nonce,previousBlockHash,hash)

   const requestPromises = [];
   bitcoin.networkNodes.forEach(networkNodeUrl =>{
    const requestOptions = {
        uri : networkNodeUrl + '/receive-new-block',
        method : 'POST',
        body : {newBlock : newBlock },
        json : true
    }
        requestPromises.push(rp(requestOptions));
 
   });
        Promise.all(requestPromises)
        .then(data =>{
            const requestOptions ={
                uri : bitcoin.currentNodeUrl + '/transaction/broadcast',
                method : 'POST',
                body : {
                    amount : 12.5,
                    sender : "00",
                    reciever : nodeAddress
                }, 
                json : true
            }
           return rp(requestOptions)

            .then(data =>{
                res.json({
                "msg":"Block mined & broadcast succesfully",
                block : newBlock
            });
            });
        });
});

app.post('/receive-new-block',function(req,res){
    const newBlock = req.body.newBlock;
    const lastBlock = bitcoin.getLastBlock();
    const correctHash = lastBlock.hash == newBlock.previousBlockHash;
    const correctIndex = lastBlock['index'] + 1 == newBlock['index'];

    if(correctHash && correctIndex){
        bitcoin.chain.push(newBlock);
        bitcoin.pendingtransactions = [];
        res.json({"note":"new block accepted and added to the chain",
        newBlock : newBlock
    })
    }else{
        res.json({"note":"new block rejected",
        newBlock : newBlock
    });
    }
})


app.post('/register-and-broadcast-node',function(req,res){
    const newNodeUrl = req.body.newNodeUrl; 
    if(bitcoin.networkNodes.indexOf(newNodeUrl) == -1) bitcoin.networkNodes.push(newNodeUrl)

    const registerNodesPromises = [];
    bitcoin.networkNodes.forEach((networkNodeUrl)=>{
        
        const requestOptions = {
            uri : networkNodeUrl + '/register-node',
            method : 'POST',
            body : {newNodeUrl : newNodeUrl},
            json : true
        }
        registerNodesPromises.push(rp(requestOptions));

    })

    Promise.all(registerNodesPromises).then((data)=>{
        const bulkRegisterOptions = {
            uri : newNodeUrl + '/register-nodes-bulk',
            method : 'POST',
            body : {allNetworkNodes : [...bitcoin.networkNodes,bitcoin.currentNodeUrl]},
            json : true
        }
           return rp(bulkRegisterOptions)
    })
    .then((data)=>{
        res.json({"note" : "New node registered with the network succesfully"})
    }) 
});

app.post('/register-node',function(req,res){

    const newNodeUrl = req.body.newNodeUrl;
    const nodeNotAlreadyPresent = bitcoin.networkNodes.indexOf(newNodeUrl) == -1 ;
    const notCurrentNode = bitcoin.currentNodeUrl != newNodeUrl;
   if(nodeNotAlreadyPresent && notCurrentNode) bitcoin.networkNodes.push(newNodeUrl);
    res.json({"Note":"Node Registered Succesfully"})

});

app.post('/register-nodes-bulk',function(req,res){
   const allNetworkNodes = req.body.allNetworkNodes;
   allNetworkNodes.forEach((networkNodeUrl)=>{
       const nodeNotAlreadyPresent = bitcoin.networkNodes.indexOf(networkNodeUrl) == -1;
       const notCurrentNode = bitcoin.currentNodeUrl != networkNodeUrl;
       if(nodeNotAlreadyPresent && notCurrentNode) bitcoin.networkNodes.push(networkNodeUrl)
   })
   res.json({"note":"Bulk registration Completed"})

});


app.get('/consensus',function(req,res){
    
    const requestPromises = [];
    bitcoin.networkNodes.forEach(networkNodeUrl =>{
        const requestOptions = {
            uri : networkNodeUrl + '/blockchain',
            method : 'GET',
            json : true
        }

       requestPromises.push(rp(requestOptions))
    });

    Promise.all(requestPromises)
    .then(blockchains =>{
        const currentChainLength = bitcoin.chain.length;
        var maxChainLength = currentChainLength;
        var newLongestChain = null;
        var newPendingtransactions = null;

        blockchains.forEach((blockchain)=>{

            if(blockchain.chain.length > maxChainLength){
                maxChainLength = blockchain.chain.length;
                newLongestChain = blockchain.chain;
                newPendingtransactions = blockchain.pendingtransactions;
            };

        });

            if(!newLongestChain || (newLongestChain && !bitcoin.chainIsValid(newLongestChain))) {
                    res.json({
                        note: "Chain has not been replaced", 
                        chain : bitcoin.chain
                });
            }else if(newLongestChain && bitcoin.chainIsValid(newLongestChain)){
                bitcoin.chain = newLongestChain;
                bitcoin.pendingtransactions = newPendingtransactions;

                res.json({
                    note : "This chain has been replaced",
                    chain : bitcoin.chain
                });
            }

            

    })

});



app.get('/block/:blockHash',function(req,res){
    
    const blockHash = req.params.blockHash;
    const correctBlock = bitcoin.getBlock(blockHash)
    res.json({
            block : correctBlock
    });

});

app.get('/transaction/:transactionId',function(req,res){
       let transactionId =  req.params.transactionId;
       let transactionData = bitcoin.getTransaction(transactionId);
       res.json({
            transaction : transactionData.transaction,
            block : transactionData.block
       });
});


app.get('/address/:address',function(req,res){
    let address = req.params.address;
    const addressData = bitcoin.getAddressData(address);

    res.json({
        addressData : addressData
    })
});


app.get('/block-explorer',function(req,res){
    res.sendFile('./block-explorer/index.html',{root : __dirname})
});


app.listen(port,function(){
    console.log(`server listening on port ${port}`)
});