const Blockchain = require('./blockchain')

const bitcoin = new Blockchain()

var previousBlockHash = "dcjhdbws3432dfsd";
var currentBlockData = [
    {
        amount : 10,
        sender : "shafey",
        reciever : "rafey"
    },

    {
        amount : 20,
        sender : "shafey",
        reciever : "hadia"
    }

]

console.log(bitcoin.proofOfWork(previousBlockHash,currentBlockData))

console.log(bitcoin.hashBlock(previousBlockHash,currentBlockData,42260))



























//2
// bitcoin.createNewBlock(2333 , '234derfwrf', '234dwfwffrerfew')

// bitcoin.newTransaction(10,"shafey","farhan")

// bitcoin.createNewBlock(2333 , '234derfwrf', '234dwfwffrerfew')

// bitcoin.newTransaction(120,"shafey","farhan")
// bitcoin.newTransaction(130,"shafey","farhan")
// bitcoin.newTransaction(140,"shafey","farhan")

// bitcoin.createNewBlock(2333 , '234derfwrf', '234dwfwffrerfew')

// console.log(bitcoin.chain[2])

//console.log(bitcoin)